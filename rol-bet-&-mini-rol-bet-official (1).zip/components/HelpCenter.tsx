
import React, { useState, useEffect } from 'react';
import { HELP_DATA } from '../constants';

interface HelpCenterProps {
  activeBot: 'rolbet' | 'minibet';
  onBotChange: (bot: 'rolbet' | 'minibet') => void;
}

const HelpCenter: React.FC<HelpCenterProps> = ({ activeBot, onBotChange }) => {
  const [activeCategory, setActiveCategory] = useState<string>(HELP_DATA[activeBot].categories[0].id);

  // Reset category when switching bots
  useEffect(() => {
    setActiveCategory(HELP_DATA[activeBot].categories[0].id);
  }, [activeBot]);

  const currentBot = HELP_DATA[activeBot];
  const currentCategory = currentBot.categories.find(c => c.id === activeCategory) || currentBot.categories[0];

  return (
    <section id="help" className="py-24 px-6 scroll-mt-20">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row items-end justify-between mb-12 gap-6">
          <div className="animate-in fade-in slide-in-from-left-4 duration-700">
            <h2 className="text-4xl md:text-5xl font-black mb-4">Centro de <span className="text-indigo-500">Ayuda</span></h2>
            <p className="text-zinc-500 max-w-md">Todos los comandos explicados de forma clara y organizada para tu servidor.</p>
          </div>
          
          <div className="flex p-1.5 glass rounded-2xl w-full md:w-auto shadow-2xl">
            <button 
              onClick={() => onBotChange('rolbet')}
              className={`flex-1 md:flex-none px-8 py-3 rounded-xl font-bold transition-all duration-300 ${activeBot === 'rolbet' ? 'bg-white text-black shadow-lg scale-105' : 'text-zinc-400 hover:text-white hover:bg-white/5'}`}
            >
              Rol Bet
            </button>
            <button 
              onClick={() => onBotChange('minibet')}
              className={`flex-1 md:flex-none px-8 py-3 rounded-xl font-bold transition-all duration-300 ${activeBot === 'minibet' ? 'bg-white text-black shadow-lg scale-105' : 'text-zinc-400 hover:text-white hover:bg-white/5'}`}
            >
              Mini Rol Bet
            </button>
          </div>
        </div>

        <div className="floating-panel rounded-[2rem] overflow-hidden flex flex-col lg:flex-row min-h-[600px] transition-all border-white/10">
          {/* Categories Sidebar */}
          <div className="w-full lg:w-80 bg-black/40 border-r border-white/5 p-8">
            <p className="text-[10px] font-black text-zinc-600 uppercase tracking-[0.2em] mb-6">Categorías</p>
            <div className="flex flex-col gap-2">
              {currentBot.categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`flex items-center gap-4 p-4 rounded-2xl text-sm font-bold transition-all duration-300 group ${activeCategory === cat.id ? 'bg-white/10 text-white translate-x-2 border border-white/5' : 'hover:bg-white/5 text-zinc-500 hover:text-zinc-300'}`}
                >
                  <span className={`text-xl transition-transform duration-300 ${activeCategory === cat.id ? 'scale-125' : 'group-hover:scale-110'}`}>{cat.icon}</span>
                  <span>{cat.title}</span>
                </button>
              ))}
            </div>
            
            <div className="mt-12 p-6 glass rounded-3xl border-dashed border-zinc-800 flex flex-col items-center text-center">
               <p className="text-xs text-zinc-500 mb-2 uppercase tracking-widest font-bold">Prefix Oficial</p>
               <p className="text-3xl font-black text-indigo-400 drop-shadow-[0_0_10px_rgba(99,102,241,0.3)]">{currentBot.prefix}</p>
            </div>
          </div>

          {/* Commands Content */}
          <div className="flex-1 p-8 lg:p-12 bg-gradient-to-br from-transparent to-white/[0.01]">
            <div key={activeCategory} className="animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="mb-10">
                <span className="text-5xl mb-4 block drop-shadow-lg">{currentCategory.icon}</span>
                <h3 className="text-3xl font-black mb-2">{currentCategory.title}</h3>
                <p className="text-zinc-500">Listado de comandos disponibles para esta categoría.</p>
              </div>

              <div className="grid gap-3">
                {currentCategory.commands.map((cmd, i) => (
                  <div key={i} className="group p-5 glass rounded-2xl hover:bg-white/[0.08] transition-all border border-white/5 flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <div className="w-2 h-2 rounded-full bg-indigo-500 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                      <div className="flex flex-col">
                        <span className="text-white font-mono font-bold text-lg">{cmd.name}</span>
                        <span className="text-zinc-600 text-[10px] uppercase font-bold tracking-tighter">Comando de Sistema</span>
                      </div>
                    </div>
                    <div className="text-zinc-400 font-medium md:text-right text-sm">
                      {cmd.description}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HelpCenter;
