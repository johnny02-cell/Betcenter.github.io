
import React, { useState, useEffect } from 'react';

const Navbar: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'Inicio', href: '#hero', icon: '🏠' },
    { label: 'Rol Bet', href: '#rolbet', icon: '🤖' },
    { label: 'Mini Rol Bet', href: '#minibet', icon: '🎯' },
    { label: 'Ayuda', href: '#help', icon: '📖' },
  ];

  return (
    <>
      {/* Desktop Floating Sidebar */}
      <nav className="fixed left-8 top-1/2 -translate-y-1/2 z-50 hidden lg:flex flex-col gap-6 p-4 glass rounded-full">
        {navItems.map((item) => (
          <a 
            key={item.label} 
            href={item.href}
            title={item.label}
            className="w-12 h-12 flex items-center justify-center rounded-full text-xl hover:bg-white/10 transition-all active:scale-90"
          >
            {item.icon}
          </a>
        ))}
      </nav>

      {/* Mobile Top Bar */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 lg:hidden px-6 py-4 ${scrolled ? 'glass' : 'bg-transparent'}`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-white text-black rounded-lg flex items-center justify-center font-bold">R</div>
            <span className="font-bold tracking-tight">ROL BET</span>
          </div>
          <button className="p-2 bg-white/5 rounded-lg border border-white/10">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/></svg>
          </button>
        </div>
      </nav>
    </>
  );
};

export default Navbar;
